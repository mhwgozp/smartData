# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.

"""
Twisted Cred: Support for verifying credentials, and providing services to user
based on those credentials.
"""
